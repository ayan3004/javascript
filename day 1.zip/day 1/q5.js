
document.getElementById("h1").innerHTML="hello my name is ayan"