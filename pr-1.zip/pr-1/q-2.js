let l = document.getElementById("box1").value
let b = document.getElementById("box2").value
 let ans = l*b
 let area = document.getElementById("ans").innerHTML=`area of ractangle :` + ans