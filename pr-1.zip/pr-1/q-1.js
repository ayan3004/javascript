let a=5
let b=3
let add=a+b
 document.getElementById("h1").innertext="`Addition of 5 and 3 is :` "+add

 let x=6
 let y=3
 let sub=x-y
 document.getElementById("h2").innertext=`substriction of 6 and 3 is :` +sub

 let s=3
 let t=2
 let mul=s*t
 document.getElementById("h3").innertext=`mult of 3 and 2 is : ` +mul

 let o=6
 let p=2
 let div=s/t
 document.getElementById("h4").innerHTML=`division of 6 and 2 is : ` +div

 let h=9
 let j=3
 let mod=h%j
 document.getElementById("h5").innerHTML=`mod of 9 and 3 is :` +mod

 