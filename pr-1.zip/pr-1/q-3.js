let l = document.getElementById("box 1").value

 let ans = (l-32)*5/9
 let area = document.getElementById("ans").innerHTML=`ferinhit :` +ans