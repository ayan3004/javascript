let l = document.getElementById("box 1").value
let b = document.getElementById("box 2").value
let o = document.getElementById("box 3").value
 let ans = (l*b*o)/100
 let area = document.getElementById("ans").innerHTML=`simple interest :` +ans